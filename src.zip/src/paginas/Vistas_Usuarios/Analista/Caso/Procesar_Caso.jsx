"use client"

import { useState, useEffect } from "react"
import PropTypes from "prop-types"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
  faCheck,
  faSpinner,
  faExclamationTriangle,
  faPlus,
  faTrash,
  faEdit,
  faSearch,
} from "@fortawesome/free-solid-svg-icons"
import "./Caso.css"

const Procesar_Caso = ({ activeView }) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)

  useEffect(() => {
    const observer = new MutationObserver(() => {
      const sidebar = document.querySelector(".sidebar")
      if (sidebar) {
        setIsSidebarCollapsed(sidebar.classList.contains("closed"))
      }
    })

    observer.observe(document.body, { attributes: true, subtree: true })

    return () => observer.disconnect()
  }, [])

  const views = {
    procesamiento: <ProcesamientoView isSidebarCollapsed={isSidebarCollapsed} />,
  }

  return (
    <div className={`caso-container ${isSidebarCollapsed ? "collapsed" : ""}`}>
      {views[activeView] || views.procesamiento}
    </div>
  )
}

const ProcesamientoView = () => {
  const [casos, setCasos] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingStatus, setProcessingStatus] = useState(null) // 'success', 'error', null
  const [statusMessage, setStatusMessage] = useState("")
  const [formMode, setFormMode] = useState("create") // 'create', 'edit'
  const [selectedCaso, setSelectedCaso] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")

  // Form state
  const [formData, setFormData] = useState({
    nombre: "",
    descripcion: "",
  })

  // Fetch casos
  useEffect(() => {
    fetchCasos()
  }, [])

  const fetchCasos = async () => {
    setIsLoading(true)
    try {
      // Intentamos obtener datos de casos si existe el endpoint
      const response = await fetch("/api/casos", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      }).catch(() => {
        // Si no existe el endpoint, usamos datos de ejemplo
        return { ok: false }
      })

      if (response.ok) {
        const data = await response.json()
        setCasos(data)
      } else {
        // Si no hay endpoint o falla, usamos datos de ejemplo
        setCasos([
          {
            idcaso: 1,
            nombre: "Caso de prueba 1",
            descripcion: "Descripción del caso de prueba 1",
            fecha_creacion: "2023-05-15T10:30:00",
            fecha_ultima_modificacion: "2023-05-16T14:20:00",
          },
          {
            idcaso: 2,
            nombre: "Caso de prueba 2",
            descripcion: "Descripción del caso de prueba 2",
            fecha_creacion: "2023-06-20T09:15:00",
            fecha_ultima_modificacion: "2023-06-21T11:45:00",
          },
          {
            idcaso: 3,
            nombre: "Caso de prueba 3",
            descripcion: "Descripción del caso de prueba 3",
            fecha_creacion: "2023-07-10T16:00:00",
            fecha_ultima_modificacion: "2023-07-12T08:30:00",
          },
        ])
      }
    } catch (error) {
      console.error("Error al obtener casos:", error)
      // En caso de error, usamos datos de ejemplo
      setCasos([
        {
          idcaso: 1,
          nombre: "Caso de prueba 1",
          descripcion: "Descripción del caso de prueba 1",
          fecha_creacion: "2023-05-15T10:30:00",
          fecha_ultima_modificacion: "2023-05-16T14:20:00",
        },
        {
          idcaso: 2,
          nombre: "Caso de prueba 2",
          descripcion: "Descripción del caso de prueba 2",
          fecha_creacion: "2023-06-20T09:15:00",
          fecha_ultima_modificacion: "2023-06-21T11:45:00",
        },
        {
          idcaso: 3,
          nombre: "Caso de prueba 3",
          descripcion: "Descripción del caso de prueba 3",
          fecha_creacion: "2023-07-10T16:00:00",
          fecha_ultima_modificacion: "2023-07-12T08:30:00",
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsProcessing(true)
    setProcessingStatus(null)

    try {
      if (formMode === "create") {
        // Crear nuevo caso
        const response = await fetch("/api/casos", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }).catch(() => {
          // Si no existe el endpoint, simulamos respuesta
          return { ok: false }
        })

        if (response.ok) {
          const newCaso = await response.json()
          setCasos([...casos, newCaso])
          setProcessingStatus("success")
          setStatusMessage("Caso creado correctamente")
          resetForm()
        } else {
          // Simulación de creación exitosa
          const newCaso = {
            idcaso: casos.length > 0 ? Math.max(...casos.map((c) => c.idcaso)) + 1 : 1,
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            fecha_creacion: new Date().toISOString(),
            fecha_ultima_modificacion: new Date().toISOString(),
          }
          setCasos([...casos, newCaso])
          setProcessingStatus("success")
          setStatusMessage("Caso creado correctamente")
          resetForm()
        }
      } else if (formMode === "edit" && selectedCaso) {
        // Actualizar caso existente
        const response = await fetch(`/api/casos/${selectedCaso.idcaso}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }).catch(() => {
          // Si no existe el endpoint, simulamos respuesta
          return { ok: false }
        })

        if (response.ok) {
          const updatedCaso = await response.json()
          setCasos(casos.map((caso) => (caso.idcaso === selectedCaso.idcaso ? updatedCaso : caso)))
          setProcessingStatus("success")
          setStatusMessage("Caso actualizado correctamente")
          resetForm()
        } else {
          // Simulación de actualización exitosa
          const updatedCaso = {
            ...selectedCaso,
            nombre: formData.nombre,
            descripcion: formData.descripcion,
            fecha_ultima_modificacion: new Date().toISOString(),
          }
          setCasos(casos.map((caso) => (caso.idcaso === selectedCaso.idcaso ? updatedCaso : caso)))
          setProcessingStatus("success")
          setStatusMessage("Caso actualizado correctamente")
          resetForm()
        }
      }
    } catch (error) {
      console.error("Error al procesar el caso:", error)
      setProcessingStatus("error")
      setStatusMessage("Error al procesar el caso")
    } finally {
      setIsProcessing(false)
      setTimeout(() => setProcessingStatus(null), 3000)
    }
  }

  const handleEdit = (caso) => {
    setSelectedCaso(caso)
    setFormData({
      nombre: caso.nombre,
      descripcion: caso.descripcion,
    })
    setFormMode("edit")
  }

  const handleDelete = async (idcaso) => {
    if (!window.confirm("¿Está seguro que desea eliminar este caso?")) {
      return
    }

    setIsProcessing(true)
    setProcessingStatus(null)

    try {
      const response = await fetch(`/api/casos/${idcaso}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      }).catch(() => {
        // Si no existe el endpoint, simulamos respuesta
        return { ok: false }
      })

      if (response.ok) {
        setCasos(casos.filter((caso) => caso.idcaso !== idcaso))
        setProcessingStatus("success")
        setStatusMessage("Caso eliminado correctamente")
      } else {
        // Simulación de eliminación exitosa
        setCasos(casos.filter((caso) => caso.idcaso !== idcaso))
        setProcessingStatus("success")
        setStatusMessage("Caso eliminado correctamente")
      }
    } catch (error) {
      console.error("Error al eliminar el caso:", error)
      setProcessingStatus("error")
      setStatusMessage("Error al eliminar el caso")
    } finally {
      setIsProcessing(false)
      setTimeout(() => setProcessingStatus(null), 3000)
    }
  }

  const resetForm = () => {
    setFormData({
      nombre: "",
      descripcion: "",
    })
    setSelectedCaso(null)
    setFormMode("create")
  }

  const handleCancel = () => {
    resetForm()
  }

  // Formatear fecha
  const formatearFecha = (fechaISO) => {
    const fecha = new Date(fechaISO)
    return fecha.toLocaleString("es-MX", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // Filtrar casos por término de búsqueda
  const filteredCasos = casos.filter(
    (caso) =>
      caso.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      caso.descripcion.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <>
      {/* Status message */}
      {processingStatus && (
        <div className={`status-message ${processingStatus}`}>
          <div className="status-icon">
            {processingStatus === "success" ? (
              <FontAwesomeIcon icon={faCheck} />
            ) : (
              <FontAwesomeIcon icon={faExclamationTriangle} />
            )}
          </div>
          <span>{statusMessage}</span>
        </div>
      )}

      <div className="caso-header">
        <h2>Gestión de Casos</h2>
        <p>Crea, edita y administra casos</p>
      </div>

      <div className="upload-area-grid">
        {/* Formulario de caso */}
        <div className="caso-form-card">
          <div className="card-header">
            <h3>Crear Nuevo Caso</h3>
          </div>
          <form onSubmit={handleSubmit} className="caso-form">
            <div className="form-group">
              <label htmlFor="nombre">Nombre del Caso:</label>
              <input
                type="text"
                id="nombre"
                name="nombre"
                value={formData.nombre}
                onChange={handleInputChange}
                required
                className="form-control"
                placeholder="Ingrese el nombre del caso"
                disabled={isProcessing}
              />
            </div>
            <div className="form-group">
              <label htmlFor="descripcion">Descripción:</label>
              <textarea
                id="descripcion"
                name="descripcion"
                value={formData.descripcion}
                onChange={handleInputChange}
                required
                className="form-control"
                rows="5"
                placeholder="Ingrese la descripción del caso"
                disabled={isProcessing}
              ></textarea>
            </div>
            <div className="form-actions">
              <button type="submit" className="submit-button" disabled={isProcessing}>
                {isProcessing ? (
                  <>
                    <FontAwesomeIcon icon={faSpinner} spin />
                    <span>Procesando...</span>
                  </>
                ) : (
                  <>
                    <FontAwesomeIcon icon={faPlus} />
                    <span>{formMode === "create" ? "Crear Caso" : "Actualizar Caso"}</span>
                  </>
                )}
              </button>
              {formMode === "edit" && (
                <button type="button" className="cancel-button" onClick={handleCancel} disabled={isProcessing}>
                  <span>Cancelar</span>
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Filtros */}
        <div className="filters-card">
          <div className="card-header">
            <h3>Filtrar Casos</h3>
          </div>
          <div className="filters-content">
            <div className="search-container">
              <input
                type="text"
                placeholder="Buscar casos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
              <FontAwesomeIcon icon={faSearch} className="search-icon" />
            </div>
            <div className="filter-group">
              <div className="checkbox-filter">
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos abiertos</span>
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos cerrados</span>
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos asignados a mí</span>
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos sin asignar</span>
                </label>
              </div>
              <div className="date-time-filters">
                <label htmlFor="fecha-inicio">
                  Fecha Inicio:
                  <input id="fecha-inicio" type="date" className="date-input" disabled={isProcessing} />
                </label>
                <label htmlFor="fecha-fin">
                  Fecha Fin:
                  <input id="fecha-fin" type="date" className="date-input" disabled={isProcessing} />
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="main-content-area-caso">
        {/* Lista de casos */}
        <div className="casos-list-card">
          <div className="card-header">
            <h3>Casos Existentes</h3>
            <span className="caso-count">{filteredCasos.length} casos</span>
          </div>

          {isLoading ? (
            <div className="loading-container">
              <FontAwesomeIcon icon={faSpinner} spin className="loading-icon" />
              <p>Cargando casos...</p>
            </div>
          ) : filteredCasos.length > 0 ? (
            <div className="casos-list">
              {filteredCasos.map((caso) => (
                <div key={caso.idcaso} className="caso-item">
                  <div className="caso-info">
                    <h4>{caso.nombre}</h4>
                    <p className="caso-description">{caso.descripcion}</p>
                    <div className="caso-meta">
                      <span>Creado: {formatearFecha(caso.fecha_creacion)}</span>
                      <span>Última modificación: {formatearFecha(caso.fecha_ultima_modificacion)}</span>
                    </div>
                  </div>
                  <div className="caso-actions">
                    <button
                      className="edit-button"
                      onClick={() => handleEdit(caso)}
                      disabled={isProcessing}
                      aria-label={`Editar caso ${caso.nombre}`}
                    >
                      <FontAwesomeIcon icon={faEdit} />
                    </button>
                    <button
                      className="delete-button"
                      onClick={() => handleDelete(caso.idcaso)}
                      disabled={isProcessing}
                      aria-label={`Eliminar caso ${caso.nombre}`}
                    >
                      <FontAwesomeIcon icon={faTrash} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-casos">
              <p>No hay casos disponibles{searchTerm ? " que coincidan con la búsqueda" : ""}</p>
              <button onClick={() => resetForm()} className="crear-caso-button" disabled={isProcessing}>
                Crear nuevo caso
              </button>
            </div>
          )}
        </div>

        {/* Filtros adicionales */}
        <div className="filters-card">
          <div className="card-header">
            <h3>Filtros Avanzados</h3>
          </div>
          <div className="filters-content">
            <div className="filter-group">
              <div className="checkbox-filter">
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos de alta prioridad</span>
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos recientes</span>
                </label>
                <label className="checkbox-label">
                  <input type="checkbox" disabled={isProcessing} />
                  <span>Casos archivados</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="processing-buttons">
        <button
          className="process-button"
          onClick={handleSubmit}
          disabled={isProcessing || !formData.nombre || !formData.descripcion}
        >
          {isProcessing ? (
            <>
              <FontAwesomeIcon icon={faSpinner} spin />
              <span>Procesando...</span>
            </>
          ) : (
            <span>Procesar Casos</span>
          )}
        </button>
        <button
          className="save-button"
          onClick={handleSubmit}
          disabled={isProcessing || !formData.nombre || !formData.descripcion}
        >
          {isProcessing ? (
            <>
              <FontAwesomeIcon icon={faSpinner} spin />
              <span>Guardando...</span>
            </>
          ) : (
            <span>Guardar en Base de Datos</span>
          )}
        </button>
        <button className="clear-button" onClick={resetForm} disabled={isProcessing}>
          <span>Limpiar Todo</span>
        </button>
      </div>
    </>
  )
}

Procesar_Caso.propTypes = {
  activeView: PropTypes.string.isRequired,
}

ProcesamientoView.propTypes = {
  isSidebarCollapsed: PropTypes.bool,
}

export default Procesar_Caso
